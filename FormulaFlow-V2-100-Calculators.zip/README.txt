FormulaFlow V2
===============
A ready-to-publish static website with 100+ calculators.

Files:
- index.html — complete responsive website
- README.txt — publishing notes

Publishing:
Upload index.html to any static hosting service or your web hosting public_html folder.
No database or server is required.

Included:
- 100+ calculators
- Search
- Category filters
- Formula library
- Math, Finance, Physics & Engineering, Geometry, Health, Converters and Everyday categories
- Mobile responsive design
- SEO metadata
- Instant browser-side calculations
